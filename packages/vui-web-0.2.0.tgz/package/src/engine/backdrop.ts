import { pageGrid } from "./grid";
import { paint, presets, Spring } from "./motion";

/**
 * What lies behind the tiles while one is emphasized (VUI VTileBackdrop and Errant Ant's start page): the tile's color
 * washes the page faintly and the bars a little more, two layers cross-fading as the emphasis moves. A tile with a
 * picture fills the page with it, blurred under a tint of its color and a fine grain, drifting slowly; the grid fades
 * out and the bars' paint fades so the picture shows behind their labels. Leaving brings the grid back with a new shot.
 */

// VTileBackdrop's strength and image strength in Errant Ant's window, and the tile backdrop tunables.
const pageWash = 0.4 * 0.28;
const barWash = 0.4 * 0.5;
const pictureOpacity = Math.max(pageWash, 0.85 * 0.6);
const drift = 60;
const blur = 90;
const margin = 180;
const tintOpacity = 0.45;
// The blur is drawn once at an eighth of the size and stretched, which looks the same and costs next to nothing.
const reduction = 8;

/** A tile's picture as the backdrop shows it: the image, its tint, and the direction it drifts in (each −1..1). */
export interface BackdropPicture {
  src: string;
  tint: string;
  direction: [number, number];
}

class WashLayer {
  color = "";
  readonly strength = new Spring(0, presets.settle, 0.002, () => paint(this.render));

  constructor(private readonly layers: HTMLElement[]) {}

  private readonly render = () => {
    for (const layer of this.layers) {
      layer.style.backgroundColor = this.color;
      layer.style.opacity = String(this.strength.value * (layer.closest(".vui-bar") ? barWash : pageWash));
    }
  };
}

class Backdrop {
  private readonly washes: [WashLayer, WashLayer];
  private arriving = 0;
  private readonly picture: HTMLElement | null;
  private readonly canvas: HTMLCanvasElement | null;
  private wanted = "";
  private tint = "";
  private image: HTMLImageElement | null = null;
  private readonly shown = new Spring(0, presets.settle, 0.002, () => paint(this.render));
  private readonly driftX = new Spring(0, presets.glide, 0.05, () => paint(this.render));
  private readonly driftY = new Spring(0, presets.glide, 0.05, () => paint(this.render));

  constructor() {
    const layers = (index: number) => [...document.querySelectorAll<HTMLElement>(".vui-backdrop, .vui-bar-paint")].map((owner) => owner.querySelectorAll<HTMLElement>(":scope > .vui-wash")[index]).filter(Boolean);
    this.washes = [new WashLayer(layers(0)), new WashLayer(layers(1))];
    this.picture = document.querySelector(".vui-picture-backdrop");
    this.canvas = this.picture?.querySelector("canvas") ?? null;
    const grain = this.picture?.querySelector<HTMLElement>(".vui-picture-grain");
    if (grain) {
      grain.style.backgroundImage = `url(${grainImage()})`;
    }

    window.addEventListener("resize", () => paint(this.blurPicture));
  }

  /** Shows `color` (or nothing) and `picture` (or none) behind the page. */
  show(color: string | null, picture: BackdropPicture | null) {
    const current = this.washes[this.arriving];
    if (color === null) {
      this.washes[0].strength.to(0);
      this.washes[1].strength.to(0);
    } else if (color !== current.color || current.strength.target === 0) {
      current.strength.to(0);
      this.arriving = 1 - this.arriving;
      const next = this.washes[this.arriving];
      next.color = color;
      next.strength.to(1);
    }

    const showsPicture = Boolean(picture && this.canvas);
    if (picture && showsPicture) {
      this.load(picture.src, picture.tint);
      this.shown.to(pictureOpacity);
      this.driftX.to(picture.direction[0] * drift);
      this.driftY.to(picture.direction[1] * drift);
    } else {
      this.shown.to(0);
    }

    document.documentElement.classList.toggle("vui-picture-shown", showsPicture);
    pageGrid()?.show(!showsPicture);
  }

  private load(src: string, tint: string) {
    if (tint !== this.tint) {
      this.tint = tint;
      paint(this.blurPicture);
    }

    if (src === this.wanted) {
      return;
    }

    this.wanted = src;
    const image = new Image();
    image.src = src;
    image.decode().then(() => {
      if (src === this.wanted) {
        this.image = image;
        this.blurPicture();
      }
    }, () => undefined);
  }

  /** VUI's tile backdrop acrylic: the picture covering the window and a margin around it, blurred, under its tint. */
  private readonly blurPicture = () => {
    const { canvas, image } = this;
    if (!canvas || !image) {
      return;
    }

    const width = Math.ceil((window.innerWidth + 2 * margin) / reduction);
    const height = Math.ceil((window.innerHeight + 2 * margin) / reduction);
    canvas.width = width;
    canvas.height = height;
    const context = canvas.getContext("2d")!;
    context.filter = `blur(${blur / reduction}px)`;
    const fit = Math.max(width / image.naturalWidth, height / image.naturalHeight);
    const drawnWidth = image.naturalWidth * fit;
    const drawnHeight = image.naturalHeight * fit;
    context.drawImage(image, (width - drawnWidth) / 2, (height - drawnHeight) / 2, drawnWidth, drawnHeight);
    context.filter = "none";
    context.globalAlpha = tintOpacity;
    context.fillStyle = this.tint;
    context.fillRect(0, 0, width, height);
  };

  private readonly render = () => {
    if (!this.picture || !this.canvas) {
      return;
    }

    this.picture.style.opacity = String(this.shown.value);
    this.canvas.style.transform = `translate(${this.driftX.value}px, ${this.driftY.value}px)`;
  };
}

/** A 128 px tile of random black and white specks, the same every time (seed 7). */
function grainImage() {
  const size = 128;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const context = canvas.getContext("2d")!;
  const pixels = context.createImageData(size, size);
  let seed = 7;
  for (let index = 0; index < pixels.data.length; index += 4) {
    // mulberry32
    seed = (seed + 0x6d2b79f5) | 0;
    let mixed = Math.imul(seed ^ (seed >>> 15), seed | 1);
    mixed ^= mixed + Math.imul(mixed ^ (mixed >>> 7), mixed | 61);
    const shade = ((mixed ^ (mixed >>> 14)) >>> 0) % 2 === 0 ? 0 : 255;
    pixels.data.set([shade, shade, shade, 255], index);
  }

  context.putImageData(pixels, 0, 0);
  return canvas.toDataURL();
}

let backdrop: Backdrop | undefined;

/** The page's backdrop. */
export function pageBackdrop() {
  return (backdrop ??= new Backdrop());
}
