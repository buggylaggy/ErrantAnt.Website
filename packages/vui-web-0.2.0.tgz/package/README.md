# VUI.Web

The VTile (Metro) language of [VUI.Avalonia](https://github.com/jusvail/VUI.Avalonia) for Astro sites, with the apps'
metrics and springs: tiles that turn in one after another, grow under the pointer and push the tiles beside and below
them, press in and lean away from the pressed point, flip to a back face now and then, and wash the page in their
color; picture tiles that fill the page behind them with their picture, blurred; a top bar painted with a blurred
copy of the start page's graph-paper grid, which makes one random move, turn and zoom when it appears. A site brings
its own colors through the `--vui-*` tokens; the package holds only what every site shares.

The package is the npm package `vui-web`, shipped as Astro source (components, a stylesheet and TypeScript engine
modules) with `astro` 7 as a peer dependency. It is private and never published to a registry: a site pins a packed
version in its own repository.

## Components

```astro
---
import "vui-web/vui.css";
import PageBackdrop from "vui-web/PageBackdrop.astro";
import PictureRoll from "vui-web/PictureRoll.astro";
import Tile from "vui-web/Tile.astro";
import TileGroup from "vui-web/TileGroup.astro";
import TileWall from "vui-web/TileWall.astro";
import TopBar from "vui-web/TopBar.astro";
---
<PageBackdrop />
<TopBar>
  <h1 class="vui-bar-brand" slot="brand">Name</h1>
  <a href="#first">First</a>
</TopBar>
<TileWall>
  <TileGroup title="Pictures" columns={6}>
    <PictureRoll cols={6} rows={4} pictures={[{ src: "/one.webp", alt: "…", caption: "One", tint: "#e2c9c4" }]} />
  </TileGroup>
  <TileGroup title="First" id="first">
    <Tile cols={4} rows={2} color="#3e4a5c" label="Label" title="Title" caption="Caption" backLabel="Back" backCaption="Shown when it flips" />
    <Tile cols={2} rows={2} color="var(--vui-accent)" title="Press me" button />
  </TileGroup>
</TileWall>
```

- `PageBackdrop`: everything behind the page, fixed to the window: the washes of the emphasized tile's color, the
  picture backdrop, and the grid (a canvas) in `--vui-grid-ink` at `--vui-grid-opacity`, which fades in with a shot.
- `TopBar`: a sticky bar of `--vui-chrome` with a blurred copy of the grid where it lies under the bar and the
  emphasized tile's wash; while a picture fills the page the paint fades. The `brand` slot takes the brand element
  (class `vui-bar-brand` gives it the pivot type); the default slot takes section links.
- `TileWall`: the page's tiles (`main`). It runs the engine: entrance, emphasis (pointer, else keyboard focus) with
  growth ×1.16 and VUI's push rule across groups, press, live flips (one tile at a time, every `live` ms, 12 000 by
  default) and picture rolls. Tiles pushed past its edge are cut off.
- `TileGroup`: a titled group, `columns` cells wide (4 by default, at most 4 on a phone); `id` makes it a link target.
- `Tile`: `cols` and `rows` (cells), `color`, a front face (`label`, the default slot, `title`, `caption`) and an
  optional back face (`backLabel`, the `back` slot, `backTitle`, `backCaption`), which makes it a live tile. `href`
  makes the tile a link and `button` a button; those press in. Other attributes go to the tile element.
- `PictureRoll`: a tile rolling through `pictures` (`src`, `alt`, `caption`, `tint`) every `interval` ms (5000 by
  default) while nothing holds it. Emphasized, its picture zooms and drifts and the page fills with it, blurred under
  its tint, while the grid fades out; leaving brings the grid back with a new shot.

Without script, every tile shows its front face and stays still.

## Tokens

Set on `:root` by the site after importing `vui.css`:

- Scheme: `--vui-canvas`, `--vui-chrome`, `--vui-ink`, `--vui-muted`, `--vui-accent`, `--vui-on-tile`,
  `--vui-tile-color` (the default tile color), `--vui-tile-edge`, `--vui-tile-opacity`, `--vui-grid-ink`,
  `--vui-grid-opacity`, `--vui-font`.
- Geometry: `--vui-cell` sets the tile cell; `--vui-u` (one VUI pixel at the apps' 960 by 600 base scale, `cell / 53`)
  scales every other size. Below 560 px one group fills the width, and tiles wider than four cells keep about their
  shape in four.

## Motion

`src/engine/motion.ts` integrates VUI's springs (settle, pop, hover, exit, turn, drift, glide) on the display's
frames, stepping a stalled frame as 1/60 s like VUI's frame loop, and asks for no frames while everything rests.
`panel.ts` ports VTilePanel's projection, press, flip, live and entrance rules; `backdrop.ts` the tile backdrop and
washes; `grid.ts` the grid, its shot and its copies.

## Using it in a site

Pack a version and copy the tarball into the site's `packages/` folder:

```sh
npm run pack
cp artifacts/vui-web-0.2.0.tgz ../ErrantAnt.Website/packages/
```

The site depends on that exact file, so its GitHub Pages build needs nothing outside its own repository:

```json
"dependencies": {
  "vui-web": "file:packages/vui-web-0.2.0.tgz"
}
```

A change to the package is a new version in `package.json`, packed and pinned by each site that takes it; a version a
site already uses is never overwritten.
