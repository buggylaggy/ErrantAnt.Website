# VUI.Web

The VTile (Metro) language of [VUI.Avalonia](https://github.com/jusvail/VUI.Avalonia) for Astro sites, with the apps'
metrics and springs: tiles that turn in one after another, grow under the pointer and push the tiles beside and below
them, press in and lean away from the pressed point, flip to a back face now and then, and wash the page in their
color; picture tiles that fill the page behind them with their picture, blurred; a top bar painted with a blurred
copy of the start page's graph-paper grid, which makes one random move, turn and zoom when it appears; and VUI's
pivot, which moves between a site's pages in place: labels spring to their new places, the page's color wipes into
the bar, tiles turn away while the next page rises, and Back reverses it. A site brings its own colors through the
`--vui-*` tokens; the package holds only what every site shares.

The package is the npm package `vui-web`, shipped as Astro source (components, a stylesheet and TypeScript engine
modules) with `astro` 7 as a peer dependency. It is private and never published to a registry: a site pins a packed
version in its own repository.

## Components

```astro
---
import "vui-web/vui.css";
import Page from "vui-web/Page.astro";
import PageBackdrop from "vui-web/PageBackdrop.astro";
import Pages from "vui-web/Pages.astro";
import PictureRoll from "vui-web/PictureRoll.astro";
import Tile from "vui-web/Tile.astro";
import TileGroup from "vui-web/TileGroup.astro";
import TileWall from "vui-web/TileWall.astro";
import TopBar from "vui-web/TopBar.astro";

const items = [
  { label: "Name", href: "/", page: "home" },
  { label: "First", href: "/#first" },
  { label: "About", href: "/about/", page: "about", accent: "#4a5568" }
];
---
<PageBackdrop />
<TopBar items={items} current="home" />
<Pages>
  <Page id="home" title="Name" current grid>
    <TileWall>
      <TileGroup title="Pictures" full>
        <PictureRoll pictures={[{ src: "/one.webp", alt: "…", caption: "One", tint: "#e2c9c4" }]} curtain />
      </TileGroup>
      <TileGroup title="First" id="first">
        <Tile cols={4} rows={2} color="#3e4a5c" label="Label" title="Title" caption="Caption" backLabel="Back" backCaption="Shown when it flips" />
        <Tile cols={2} color="#4a5568" title="About" href="/about/" data-vui-page="about" />
      </TileGroup>
    </TileWall>
  </Page>
  <Page id="about" title="About — Name">…</Page>
</Pages>
```

Every page file renders all the pages with its own `current`, so each file works alone and without script, while
script moves between them in place.

- `PageBackdrop`: everything behind the page, fixed to the window: the washes of the emphasized tile's color, the
  picture backdrop, the current page's color, and the grid (a canvas) in `--vui-grid-ink` at `--vui-grid-opacity`,
  which fades in with a shot on pages that show it.
- `TopBar`: VUI's pivot. `items` name pages (`page`, with an `accent`) and in-page sections (no `page`); the first
  item is the start page; `current` is the page on show. The current label stands large and first, the others follow
  at 0.42 and 0.55 opacity, hidden on any other page, where a back button shows. Moving to a page springs the labels
  to their places, wipes the page's accent into the bar behind a slanted edge (from the side of the chosen item) and
  tints the page; Back (the button, Escape or the browser's Back) reverses it. The bar is painted with the chrome
  color, a blurred copy of the grid, the accent and the emphasized tile's wash, and fades while a picture fills the
  page.
- `Pages` and `Page`: the site's pages, stacked so a leaving and an arriving page show at once. A `Page` has an `id`
  (an item's `page`), a document `title`, `grid` to show the grid, and `current`. Links with `data-vui-page` (bar
  items, tiles) move between pages with history; the leaving page's tiles turn away and an opening tile dives, or the
  page sinks, while the arriving page rises or its tiles come back.
- `TileWall`: the tiles of a page (`main`). It runs the engine: entrance, emphasis (pointer, else keyboard focus) with
  growth ×1.16 and VUI's push rule across groups, press, live flips (one tile at a time, every `live` ms, 12 000 by
  default), picture rolls, and leaving and coming back with its page. Tiles pushed past its edge are cut off.
- `TileGroup`: a titled group, `columns` cells wide (4 by default, at most 4 on a phone); `id` makes it a link target.
  A `full` group spans the wall for one tile centered at 1/1.16 of its width, shaped by `--vui-aspect` and no taller
  than the first screen; that tile grows from its center to the full width.
- `Tile`: `cols` and `rows` (cells), `color`, a front face (`label`, the default slot, `title`, `caption`) and an
  optional back face (`backLabel`, the `back` slot, `backTitle`, `backCaption`), which makes it a live tile. `href`
  makes the tile a link and `button` a button; those press in. Other attributes go to the tile element.
- `PictureRoll`: a tile rolling through `pictures` (`src`, `alt`, `caption`, `tint`) every `interval` ms (5000 by
  default) while nothing holds it; `curtain` lays VUI's dark curtain over it until it is emphasized. Emphasized, its
  picture zooms and drifts and the page fills with it, blurred under its tint, while the grid fades out; leaving brings
  the grid back with a new shot.

Without script, every tile shows its front face and stays still, and page links load their page files.

## Tokens

Set on `:root` by the site after importing `vui.css`:

- Scheme: `--vui-canvas`, `--vui-chrome`, `--vui-ink`, `--vui-muted`, `--vui-accent`, `--vui-on-tile`,
  `--vui-tile-color` (the default tile color), `--vui-tile-edge`, `--vui-tile-opacity`, `--vui-grid-ink`,
  `--vui-grid-opacity`, `--vui-font`.
- Geometry: `--vui-cell` sets the tile cell; `--vui-u` (one VUI pixel at the apps' 960 by 600 base scale, `cell / 53`)
  scales every other size. Below 560 px one group fills the width, and tiles wider than four cells keep about their
  shape in four.

## Motion

`src/engine/motion.ts` integrates VUI's springs (settle, pop, hover, exit, turn, drift, glide) on the display's
frames, stepping a stalled frame as 1/60 s like VUI's frame loop, and asks for no frames while everything rests.
`panel.ts` ports VTilePanel's projection, press, flip, live, entrance, exit and dive rules; `pivot.ts` VPivot, its
backdrop wipe and the page transitions; `backdrop.ts` the tile backdrop and washes; `grid.ts` the grid, its shot and
its copies.

## Using it in a site

Pack a version and copy the tarball into the site's `packages/` folder:

```sh
npm run pack
cp artifacts/vui-web-0.3.0.tgz ../ErrantAnt.Website/packages/
```

The site depends on that exact file, so its GitHub Pages build needs nothing outside its own repository:

```json
"dependencies": {
  "vui-web": "file:packages/vui-web-0.3.0.tgz"
}
```

A change to the package is a new version in `package.json`, packed and pinned by each site that takes it; a version a
site already uses is never overwritten.
