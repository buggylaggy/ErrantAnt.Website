/**
 * A tile's size and color as the attributes its element carries. A tile wider than a phone's four columns keeps about
 * its shape there: four columns and as many rows as that shape needs.
 */
export function tileGeometry(cols: number, rows: number, color?: string) {
  const phoneRows = cols > 4 ? Math.ceil((rows * 4) / cols) : rows;
  return {
    style: `--vui-cols: ${cols}; --vui-rows: ${rows}; --vui-phone-rows: ${phoneRows};${color ? ` --vui-tile-color: ${color};` : ""}`,
    "data-wide": cols > 4 ? "" : undefined
  };
}
