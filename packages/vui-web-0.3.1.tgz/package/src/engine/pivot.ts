import { pageBackdrop } from "./backdrop";
import { paint, presets, Spring } from "./motion";
import { wallPanel } from "./panel";

/**
 * VUI's VPivot for the web. A site's pages are sections of one document (each page file shows its own), the top bar's
 * items name them, and moving between pages happens in place, with the browser's history. The chosen item takes the
 * large first place and the others shrink after it, hidden on any page but the first; the page's color wipes into the
 * bar behind a slanted edge and tints the page; the leaving page's tiles turn away (the tile that opened the page
 * dives) or the page sinks, while the arriving page rises or its tiles come back. Back (the bar's back button, Escape
 * or the browser's Back) reverses it.
 */

// VUI's pivot metrics (controls.json, VPivotBackdrop) and Errant Ant's tint strengths.
const motion = {
  smallScale: 0.42,
  smallOpacity: 0.55,
  hoverScale: 1.12,
  slant: 60,
  barTint: 0.4 * 0.5,
  pageTint: 0.4 * 0.28,
  pageOffset: 24,
  collapseAfter: 700
};

class Label {
  readonly x = this.spring(0, 0.05);
  readonly y = this.spring(0, 0.05);
  readonly scale = this.spring(1, 0.001);
  readonly opacity = this.spring(1, 0.002);
  readonly hover = new Spring(0, presets.hover, 0.001, () => paint(this.render));

  constructor(readonly element: HTMLAnchorElement) {
    element.addEventListener("pointerenter", () => this.hover.to(element.classList.contains("vui-pivot-current") ? 0 : 1));
    element.addEventListener("pointerleave", () => this.hover.to(0));
  }

  get page() {
    return this.element.dataset.vuiPage;
  }

  get accent() {
    return this.element.dataset.vuiAccent ?? "transparent";
  }

  private spring(value: number, epsilon: number) {
    return new Spring(value, presets.settle, epsilon, () => paint(this.render));
  }

  readonly render = () => {
    const grow = 1 + (motion.hoverScale - 1) * this.hover.value;
    const scale = this.scale.value * grow;
    const still = this.x.value === 0 && this.y.value === 0 && scale === 1;
    this.element.style.transform = still ? "" : `translate(${this.x.value}px, ${this.y.value}px) scale(${scale})`;
    this.element.style.opacity = String(this.opacity.value + (1 - this.opacity.value) * this.hover.value);
  };
}

class Pivot {
  private readonly nav: HTMLElement;
  private readonly labels: Label[];
  private readonly back: HTMLAnchorElement | null;
  private readonly pages: HTMLElement[];
  private readonly home: string;
  private current: string;
  private readonly scrolls = new Map<string, number>();
  private readonly turns = new Map<HTMLElement, number>();
  private readonly sinking = new Map<HTMLElement, Spring>();
  private readonly wipe = new Spring(1, presets.settle, 0.002, () => paint(this.renderTint));
  private tint = { from: "transparent", to: "transparent", direction: 1 };
  private collapse = 0;

  constructor(private readonly bar: HTMLElement) {
    this.nav = bar.querySelector<HTMLElement>(".vui-pivot")!;
    this.labels = [...this.nav.querySelectorAll<HTMLAnchorElement>(".vui-pivot-item")].map((element) => new Label(element));
    this.back = bar.querySelector<HTMLAnchorElement>(".vui-back");
    this.pages = [...document.querySelectorAll<HTMLElement>(".vui-page")];
    this.home = this.labels.find((label) => label.page)?.page ?? "";
    this.current = this.pages.find((page) => !page.hidden)?.dataset.vuiPage ?? this.home;
    this.tint.to = this.accentOf(this.current);
    this.renderTint();
    for (const label of this.labels) {
      label.opacity.jump(this.restOpacity(label));
    }

    for (const page of this.pages) {
      const sunk: Spring = new Spring(page.hidden ? 1 : 0, presets.settle, 0.001, () => paint(() => {
        page.style.transform = sunk.value === 0 ? "" : `translateY(${sunk.value * motion.pageOffset}px)`;
        page.style.opacity = sunk.value === 0 ? "" : String(1 - sunk.value);
      }));
      this.sinking.set(page, sunk);
    }

    history.scrollRestoration = "manual";
    history.replaceState({ ...history.state, vuiPage: this.current }, "");
    document.addEventListener("click", this.click);
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && this.current !== this.home) {
        this.goBack();
      }
    });
    window.addEventListener("popstate", (event) => this.go(event.state?.vuiPage ?? this.pageAt(location.pathname), null, false));
    window.addEventListener("resize", () => paint(this.renderTint));
  }

  private readonly click = (event: MouseEvent) => {
    if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
      return;
    }

    const link = (event.target as Element).closest<HTMLAnchorElement>("a[data-vui-page], a.vui-back");
    if (!link) {
      return;
    }

    event.preventDefault();
    if (link === this.back) {
      this.goBack();
    } else {
      this.go(link.dataset.vuiPage!, link.classList.contains("vui-tile") ? link : null, true, link.href);
    }
  };

  /** Back to the first page: through the history when this document came from there, else as a new step. */
  private goBack() {
    if (history.state?.vuiFrom) {
      history.back();
    } else {
      this.go(this.home, null, true, this.hrefOf(this.home));
    }
  }

  private go(to: string, opened: HTMLElement | null, push: boolean, href?: string) {
    const from = this.current;
    const arriving = this.pageOf(to);
    const leaving = this.pageOf(from);
    if (to === from || !arriving || !leaving) {
      return;
    }

    if (push) {
      history.pushState({ vuiPage: to, vuiFrom: from }, "", href ?? this.hrefOf(to));
    }

    this.current = to;
    document.title = arriving.dataset.title ?? document.title;
    this.arrange();
    // The new color comes in from the side of the chosen item: from the right when it lies further along the bar.
    this.tint = { from: this.accentOf(from), to: this.accentOf(to), direction: this.indexOf(to) > this.indexOf(from) ? 1 : -1 };
    this.wipe.jump(0);
    this.wipe.to(1);
    pageBackdrop().allowGrid(arriving.hasAttribute("data-vui-grid"));
    // The leaving page stays where it is on screen while the window scrolls to where the arriving page was left.
    this.scrolls.set(from, window.scrollY);
    this.pin(leaving);
    this.unpin(arriving);
    arriving.hidden = false;
    window.scrollTo({ top: this.scrolls.get(to) ?? 0, behavior: "instant" });
    const turn = this.bump(leaving);
    this.bump(arriving);
    this.leave(leaving, opened).then(() => {
      if (this.turns.get(leaving) === turn) {
        leaving.hidden = true;
        this.unpin(leaving);
      }
    });
    this.arrive(arriving);
  }

  private leave(page: HTMLElement, opened: HTMLElement | null) {
    const wall = page.querySelector<HTMLElement>(".vui-groups");
    const panel = wall ? wallPanel(wall) : undefined;
    if (panel) {
      return panel.leave(opened);
    }

    const sunk = this.sinking.get(page)!;
    sunk.to(1, presets.exit);
    return new Promise<void>((resolve) => {
      const check = window.setInterval(() => {
        if (sunk.resting || sunk.target !== 1) {
          window.clearInterval(check);
          resolve();
        }
      }, 50);
    });
  }

  private arrive(page: HTMLElement) {
    const wall = page.querySelector<HTMLElement>(".vui-groups");
    const panel = wall ? wallPanel(wall) : undefined;
    if (panel) {
      panel.arrive();
    } else {
      this.sinking.get(page)!.to(0, presets.settle);
    }
  }

  /** The labels' new places: each springs from where it was, the chosen one large and first. */
  private arrange() {
    window.clearTimeout(this.collapse);
    const sub = this.current !== this.home;
    // Labels hidden on a sub page take their small places again while they move.
    this.nav.classList.add("vui-pivot-moving");
    const before = this.labels.map((label) => label.element.getBoundingClientRect());
    for (const label of this.labels) {
      const current = label.page === this.current;
      label.element.style.transform = "";
      label.element.classList.toggle("vui-pivot-current", current);
      if (current) {
        label.element.setAttribute("aria-current", "page");
      } else {
        label.element.removeAttribute("aria-current");
      }
    }

    this.nav.classList.toggle("vui-pivot-sub", sub);
    if (this.back) {
      this.back.hidden = !sub;
    }

    this.labels.forEach((label, index) => {
      const after = label.element.getBoundingClientRect();
      label.x.jump(before[index].left - after.left);
      label.y.jump(before[index].bottom - after.bottom);
      label.scale.jump(after.width > 0 ? before[index].width / after.width : 1);
      label.x.to(0);
      label.y.to(0);
      label.scale.to(1);
      label.opacity.to(this.restOpacity(label));
      label.hover.to(0);
    });
    if (sub) {
      this.collapse = window.setTimeout(() => this.nav.classList.remove("vui-pivot-moving"), motion.collapseAfter);
    } else {
      this.nav.classList.remove("vui-pivot-moving");
    }
  }

  private restOpacity(label: Label) {
    return label.page === this.current ? 1 : this.current === this.home ? motion.smallOpacity : 0;
  }

  /** VPivotBackdrop: the new color behind a slanted edge crossing the bar, the old one on the other side. */
  private readonly renderTint = () => {
    const progress = this.wipe.value;
    const { from, to, direction } = this.tint;
    const width = this.bar.clientWidth;
    const height = this.bar.clientHeight;
    const top = (width + motion.slant) * (1 - progress);
    const bottom = top - motion.slant;
    const polygon = (points: [number, number][]) => `polygon(${points.map(([x, y]) => `${direction > 0 ? x : width - x}px ${y}px`).join(", ")})`;
    const [old, next] = this.bar.querySelectorAll<HTMLElement>(".vui-pivot-tint");
    if (old && next) {
      old.style.backgroundColor = from;
      old.style.clipPath = polygon([[0, 0], [top, 0], [bottom, height], [0, height]]);
      next.style.backgroundColor = to;
      next.style.clipPath = polygon([[top, 0], [width, 0], [width, height], [bottom, height]]);
    }

    const [oldPage, nextPage] = document.querySelectorAll<HTMLElement>(".vui-backdrop > .vui-page-tint");
    if (oldPage && nextPage) {
      oldPage.style.backgroundColor = from;
      oldPage.style.opacity = String(motion.pageTint * (1 - progress));
      nextPage.style.backgroundColor = to;
      nextPage.style.opacity = String(motion.pageTint * progress);
    }
  };

  private pin(page: HTMLElement) {
    if (page.style.position === "fixed") {
      return;
    }

    const box = page.getBoundingClientRect();
    Object.assign(page.style, { position: "fixed", top: `${box.top}px`, left: `${box.left}px`, width: `${box.width}px`, zIndex: "0" });
  }

  private unpin(page: HTMLElement) {
    Object.assign(page.style, { position: "", top: "", left: "", width: "", zIndex: "" });
  }

  /** Starts a new turn for `page`, so a step still pending from an earlier one does nothing. */
  private bump(page: HTMLElement) {
    const turn = (this.turns.get(page) ?? 0) + 1;
    this.turns.set(page, turn);
    return turn;
  }

  private pageOf(id: string) {
    return this.pages.find((page) => page.dataset.vuiPage === id);
  }

  private hrefOf(page: string) {
    return this.labels.find((label) => label.page === page)?.element.href ?? "/";
  }

  private pageAt(path: string) {
    return this.labels.find((label) => label.page && new URL(label.element.href).pathname === path)?.page ?? this.home;
  }

  private accentOf(page: string) {
    return this.labels.find((label) => label.page === page)?.accent ?? "transparent";
  }

  private indexOf(page: string) {
    return this.labels.findIndex((label) => label.page === page);
  }
}

/** Starts the pivot of the page's top bar. */
export function startPivot() {
  const bar = document.querySelector<HTMLElement>(".vui-bar");
  if (bar?.querySelector(".vui-pivot")) {
    new Pivot(bar);
  }
}
