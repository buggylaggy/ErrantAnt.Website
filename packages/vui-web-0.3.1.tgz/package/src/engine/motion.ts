/**
 * VUI's springs (VUI.Avalonia Motion/SpringValue.cs and motion.json) on the display's frames: unit mass, damping
 * 2ζ√k, integrated in substeps of at most 1/240 s. A spring at rest asks for no frames, so a still page runs nothing.
 */
export interface Preset {
  stiffness: number;
  dampingRatio: number;
}

export const presets = {
  settle: { stiffness: 260, dampingRatio: 0.9 },
  pop: { stiffness: 380, dampingRatio: 0.72 },
  hover: { stiffness: 520, dampingRatio: 0.85 },
  exit: { stiffness: 500, dampingRatio: 1 },
  turn: { stiffness: 70, dampingRatio: 0.92 },
  drift: { stiffness: 4, dampingRatio: 1 },
  glide: { stiffness: 1.5, dampingRatio: 1 }
} satisfies Record<string, Preset>;

/** Something that moves frame by frame; `tick` returns whether it still moves. */
export interface Ticker {
  tick(seconds: number): boolean;
}

const moving = new Set<Ticker>();
const painters = new Set<() => void>();
let frame = 0;
let last = 0;

/** Keeps `ticker` running on every frame until it says it has stopped. */
export function animate(ticker: Ticker) {
  moving.add(ticker);
  request();
}

/** Runs `painter` once on the next frame, after every ticker has stepped; asking twice runs it once. */
export function paint(painter: () => void) {
  painters.add(painter);
  request();
}

function request() {
  frame ||= requestAnimationFrame(run);
}

function run(now: number) {
  frame = 0;
  // A first frame, a stalled one or a clock jump steps one 60 Hz frame, as VUI's frame loop does.
  let seconds = last ? (now - last) / 1000 : 1 / 60;
  if (seconds <= 0 || seconds > 0.1) {
    seconds = 1 / 60;
  }

  for (const ticker of [...moving]) {
    if (!ticker.tick(seconds)) {
      moving.delete(ticker);
    }
  }

  const due = [...painters];
  painters.clear();
  for (const painter of due) {
    painter();
  }

  last = moving.size > 0 ? now : 0;
  if (moving.size > 0) {
    request();
  }
}

/** A value that follows its target like a damped spring; `changed` runs after every step. */
export class Spring implements Ticker {
  value: number;
  target: number;
  velocity = 0;

  constructor(
    value: number,
    private preset: Preset,
    private readonly epsilon: number,
    private readonly changed: () => void
  ) {
    this.value = value;
    this.target = value;
  }

  get resting() {
    return Math.abs(this.value - this.target) < this.epsilon && Math.abs(this.velocity) < 10 * this.epsilon;
  }

  /** Heads for `target`, keeping the current velocity; `preset` replaces the spring's feel from now on. */
  to(target: number, preset = this.preset) {
    this.preset = preset;
    this.target = target;
    if (!this.resting) {
      animate(this);
    }
  }

  /** Stands still at `value`. */
  jump(value: number) {
    this.value = value;
    this.target = value;
    this.velocity = 0;
    this.changed();
  }

  tick(seconds: number) {
    const stiffness = this.preset.stiffness;
    const damping = 2 * this.preset.dampingRatio * Math.sqrt(stiffness);
    const steps = Math.ceil(seconds * 240);
    const step = seconds / steps;
    for (let index = 0; index < steps; index++) {
      this.velocity += (-stiffness * (this.value - this.target) - damping * this.velocity) * step;
      this.value += this.velocity * step;
    }

    const still = this.resting;
    if (still) {
      this.value = this.target;
      this.velocity = 0;
    }

    this.changed();
    return !still;
  }
}
