import { animate, paint, presets, Spring } from "./motion";

/**
 * The page's graph paper, drawn like the start-page grid of VUI's apps (ErrantAnt GridBackdrop): major lines with
 * fainter minor lines between them in --vui-grid-ink at --vui-grid-opacity, only those that cross the window. Each
 * time it is shown it fades in and makes one shot, a move, a turn or both, always with a zoom, of random size and
 * duration along a quick-to-slow easing, then stands still. Bars hold blurred copies (`canvas.vui-grid-copy`) that
 * draw the same lines where they lie under them and follow the shot and the fade.
 */

// ErrantAnt's shell.grid.* tunables; lengths are in VUI units (--vui-u).
const settings = {
  spacing: 140,
  minorDivisions: 4,
  width: 1.4,
  minorWidth: 1,
  minorOpacityRatio: 0.5,
  minimumDuration: 1500,
  maximumDuration: 3600,
  minimumTurn: 6,
  maximumTurn: 25,
  minimumShift: 40,
  maximumShift: 180,
  minimumZoom: 1.15,
  maximumZoom: 1.5,
  minimumScale: 0.7,
  maximumScale: 1.6
};

interface Pose {
  angle: number;
  scale: number;
  x: number;
  y: number;
}

const between = (minimum: number, maximum: number) => minimum + Math.random() * (maximum - minimum);

class Grid {
  private pose: Pose = { angle: 0, scale: 1, x: 0, y: 0 };
  private readonly fade = new Spring(0, presets.settle, 0.002, () => paint(this.draw));
  private present = false;

  constructor(private readonly canvas: HTMLCanvasElement) {
    window.addEventListener("resize", () => paint(this.draw));
    const resized = new ResizeObserver(() => paint(this.draw));
    for (const copy of document.querySelectorAll("canvas.vui-grid-copy")) {
      resized.observe(copy);
    }
  }

  /** Shows the grid with a new shot, or fades it out. */
  show(present: boolean) {
    if (present === this.present) {
      return;
    }

    this.present = present;
    this.fade.to(present ? 1 : 0);
    if (present) {
      this.shoot();
    }
  }

  private shoot() {
    const unit = this.unit;
    const start = this.wrapped(this.pose, settings.spacing * unit);
    // A shot moves, turns, or does both; it always zooms, one way only, staying inside the allowed scales.
    const kind = Math.floor(Math.random() * 3);
    const turn = kind === 0 ? 0 : between(settings.minimumTurn, settings.maximumTurn) * (Math.random() < 0.5 ? -1 : 1);
    const heading = Math.random() * Math.PI * 2;
    const shift = kind === 1 ? 0 : between(settings.minimumShift, settings.maximumShift) * unit;
    const zoom = between(settings.minimumZoom, settings.maximumZoom);
    const zoomIn = start.scale * zoom <= settings.maximumScale && (start.scale / zoom < settings.minimumScale || Math.random() < 0.5);
    const end: Pose = {
      angle: start.angle + turn,
      scale: Math.min(Math.max(zoomIn ? start.scale * zoom : start.scale / zoom, settings.minimumScale), settings.maximumScale),
      x: start.x + Math.cos(heading) * shift,
      y: start.y + Math.sin(heading) * shift
    };
    const duration = between(settings.minimumDuration, settings.maximumDuration) / 1000;
    let elapsed = 0;
    this.pose = start;
    animate({
      tick: (seconds) => {
        elapsed = Math.min(elapsed + seconds, duration);
        const eased = 1 - (1 - elapsed / duration) ** 4;
        this.pose = {
          angle: start.angle + (end.angle - start.angle) * eased,
          // Zooming evenly in proportion, so an equal stretch of time looks like an equal step in or out.
          scale: start.scale * (end.scale / start.scale) ** eased,
          x: start.x + (end.x - start.x) * eased,
          y: start.y + (end.y - start.y) * eased
        };
        paint(this.draw);
        return elapsed < duration;
      }
    });
  }

  /** The same grid with its angle within a quarter turn and its pan within one major cell. */
  private wrapped(pose: Pose, cell: number): Pose {
    const angle = ((pose.angle % 90) + 90) % 90;
    const radians = (angle * Math.PI) / 180;
    const cos = Math.cos(radians);
    const sin = Math.sin(radians);
    const wrap = (value: number) => ((value % cell) + cell) % cell;
    const u = wrap((pose.x * cos + pose.y * sin) / pose.scale);
    const v = wrap((-pose.x * sin + pose.y * cos) / pose.scale);
    return { angle, scale: pose.scale, x: (u * cos - v * sin) * pose.scale, y: (u * sin + v * cos) * pose.scale };
  }

  private get unit() {
    return parseFloat(getComputedStyle(this.canvas).getPropertyValue("--vui-u")) || 1;
  }

  private readonly draw = () => {
    this.drawOn(this.canvas, 0, 0);
    for (const copy of document.querySelectorAll<HTMLCanvasElement>("canvas.vui-grid-copy")) {
      const box = copy.getBoundingClientRect();
      this.drawOn(copy, box.left, box.top);
    }
  };

  /** Draws the grid of the whole window into `canvas`, whose top-left corner lies at (left, top) in the window. */
  private drawOn(canvas: HTMLCanvasElement, left: number, top: number) {
    const context = canvas.getContext("2d");
    if (!context) {
      return;
    }

    const style = getComputedStyle(this.canvas);
    const unit = this.unit;
    const ink = style.getPropertyValue("--vui-grid-ink").trim();
    const opacity = parseFloat(style.getPropertyValue("--vui-grid-opacity"));
    const ratio = window.devicePixelRatio || 1;
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;
    if (canvas.width !== Math.round(width * ratio) || canvas.height !== Math.round(height * ratio)) {
      canvas.width = Math.round(width * ratio);
      canvas.height = Math.round(height * ratio);
    }

    context.setTransform(ratio, 0, 0, ratio, -left * ratio, -top * ratio);
    context.clearRect(left, top, width, height);
    if (this.fade.value <= 0) {
      return;
    }

    const { angle, scale, x, y } = this.pose;
    const radians = (angle * Math.PI) / 180;
    const cos = Math.cos(radians);
    const sin = Math.sin(radians);
    const step = (settings.spacing * unit) / settings.minorDivisions;
    const centerX = window.innerWidth / 2 + x;
    const centerY = window.innerHeight / 2 + y;
    // Every line that can cross the window: a radius around the grid's center in grid space.
    const reach = (Math.hypot(window.innerWidth, window.innerHeight) / 2 + Math.hypot(x, y)) / scale;
    const count = Math.ceil(reach / step);
    const toWindow = (u: number, v: number): [number, number] => [
      centerX + (u * cos - v * sin) * scale,
      centerY + (u * sin + v * cos) * scale
    ];

    context.strokeStyle = ink;
    for (const major of [false, true]) {
      context.beginPath();
      for (let line = -count; line <= count; line++) {
        if ((line % settings.minorDivisions === 0) !== major) {
          continue;
        }

        const offset = line * step;
        context.moveTo(...toWindow(offset, -reach));
        context.lineTo(...toWindow(offset, reach));
        context.moveTo(...toWindow(-reach, offset));
        context.lineTo(...toWindow(reach, offset));
      }

      context.globalAlpha = opacity * this.fade.value * (major ? 1 : settings.minorOpacityRatio);
      context.lineWidth = major ? settings.width : settings.minorWidth;
      context.stroke();
    }
  }
}

let grid: Grid | null | undefined;

/** The page's grid, or null when the page has none. */
export function pageGrid() {
  if (grid === undefined) {
    const canvas = document.querySelector<HTMLCanvasElement>("canvas.vui-grid");
    grid = canvas ? new Grid(canvas) : null;
  }

  return grid;
}
