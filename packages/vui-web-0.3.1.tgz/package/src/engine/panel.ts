import { pageBackdrop, type BackdropPicture } from "./backdrop";
import { paint, presets, Spring } from "./motion";

/**
 * VUI's VTilePanel for the web: every tile of a tile wall turns in on its first showing, one after another; the tile
 * under the pointer (or the keyboard focus) grows from its top-left corner (a full-width tile from its center) and
 * pushes the tiles right of and below it along, across groups, and washes the page in its color; a pressed link or
 * button tile presses in and leans away from the pressed point; live tiles (those with a back face) flip one at a
 * time; a picture roll turns to its next picture on its own interval. When its page goes away the tiles turn away
 * and an opened tile dives; when the page comes back they return. Tiles move by transforms only, so the CSS grid's
 * layout is the rest position.
 */

// VUI's motion.tile.* tunables and the picture's hover zoom.
const motion = {
  emphasisScale: 1.16,
  pressScale: 0.96,
  tiltDegrees: 10,
  turnDegrees: 70,
  turnOffset: 28,
  depth: 800,
  enterStagger: 40,
  exitStagger: 25,
  // A wall of more tiles shares this many tiles' stagger time among them all, so a big wall turns no slower.
  staggerSpan: 24,
  openScale: 5,
  pictureZoom: 1.12
};

interface Rect {
  x: number;
  y: number;
  width: number;
  height: number;
}

class TileMotion {
  rest: Rect = { x: 0, y: 0, width: 1, height: 1 };
  /** The face shown at rest, and the one a flip turns to. */
  face = 0;
  next = 1;
  direction: [number, number] = [0, 0];
  readonly faces: HTMLElement[];
  readonly hover = this.spring(0, presets.hover, 0.001);
  readonly x = this.spring(0, presets.hover, 0.05);
  readonly y = this.spring(0, presets.hover, 0.05);
  readonly width = this.spring(1, presets.hover, 0.05);
  readonly height = this.spring(1, presets.hover, 0.05);
  readonly press = this.spring(0, presets.hover, 0.001);
  readonly tiltX = this.spring(0, presets.hover, 0.02);
  readonly tiltY = this.spring(0, presets.hover, 0.02);
  readonly away = this.spring(-1, presets.settle, 0.001);
  readonly dive = this.spring(0, presets.exit, 0.001);
  readonly flip = this.spring(0, presets.turn, 0.2);
  readonly zoom = this.spring(0, presets.settle, 0.001);
  readonly driftX = this.spring(0, presets.drift, 0.05);
  readonly driftY = this.spring(0, presets.drift, 0.05);

  constructor(readonly element: HTMLElement) {
    this.faces = [...element.querySelectorAll<HTMLElement>(":scope > .vui-tile-faces > .vui-tile-face")];
  }

  /** Milliseconds between the pictures of a picture roll, or 0 for any other tile. */
  get rollInterval() {
    return Number(this.element.dataset.vuiRoll) || 0;
  }

  get live() {
    return this.rollInterval === 0 && this.faces.length > 1;
  }

  get interactive() {
    return this.element.matches("a, button");
  }

  /** A tile alone across its group's full width grows from its center, so it stays in view. */
  get centered() {
    return this.element.closest(".vui-group-full") !== null;
  }

  /** The face on show now: past a quarter turn a flip shows the face it turns to. */
  get shown() {
    return this.flip.value > 90 ? this.next : this.face;
  }

  /** The tile's color for the backdrop: a picture's tint, or the tile color. */
  get wash() {
    const face = this.faces[this.shown];
    return face?.dataset.tint ?? getComputedStyle(this.element).getPropertyValue("--vui-tile-color").trim();
  }

  get picture(): BackdropPicture | null {
    const face = this.faces[this.shown];
    const image = face?.querySelector<HTMLImageElement>(".vui-tile-picture");
    return image && face.dataset.tint ? { src: image.currentSrc || image.src, tint: face.dataset.tint, direction: this.direction } : null;
  }

  /** Turns a roll to its next picture. */
  roll() {
    this.next = (this.face + 1) % this.faces.length;
    this.flip.to(180);
  }

  private spring(value: number, preset: typeof presets.hover, epsilon: number) {
    return new Spring(value, preset, epsilon, () => paint(this.render));
  }

  readonly render = () => {
    const { rest } = this;
    const press = (1 - (1 - motion.pressScale) * this.press.value) * (1 + (motion.openScale - 1) * this.dive.value);
    const scaleX = (this.width.value / rest.width) * press;
    const scaleY = (this.height.value / rest.height) * press;
    const away = this.away.value;
    const shown = (1 - Math.abs(away)) * (1 - this.dive.value);
    const shiftX = this.x.value + this.width.value / 2 - (rest.x + rest.width / 2) + away * motion.turnOffset;
    const shiftY = this.y.value + this.height.value / 2 - (rest.y + rest.height / 2);
    const turnX = this.tiltX.value;
    const turnY = this.tiltY.value + away * motion.turnDegrees;
    const turned = Math.abs(turnX) > 0.05 || Math.abs(turnY) > 0.05;
    const moved = Math.abs(shiftX) > 0.01 || Math.abs(shiftY) > 0.01 || Math.abs(scaleX - 1) > 1e-4 || Math.abs(scaleY - 1) > 1e-4;
    const rotation = turned ? ` perspective(${motion.depth}px) rotateX(${turnX}deg) rotateY(${turnY}deg)` : "";
    this.element.style.transform = moved || turned ? `translate(${shiftX}px, ${shiftY}px)${rotation} scale(${scaleX}, ${scaleY})` : "";
    this.element.style.opacity = shown === 1 ? "" : String(shown);
    const edge = this.element.querySelector<HTMLElement>(":scope > .vui-tile-edge");
    if (edge) {
      edge.style.opacity = String(this.hover.value);
    }

    // A roll stops at the next picture and stands there as its new rest.
    if (this.rollInterval > 0 && this.flip.target === 180 && this.flip.resting) {
      this.face = this.next;
      this.flip.jump(0);
      return;
    }

    // The faces turn about the horizontal axis; the tile's color and edge stay put.
    const angle = this.flip.value <= 90 ? this.flip.value : this.flip.value - 180;
    const faces = this.faces[0]?.parentElement;
    if (faces) {
      faces.style.transform = Math.abs(angle) > 0.05 ? `perspective(${motion.depth}px) rotateX(${angle}deg)` : "";
    }

    const face = this.shown;
    this.faces.forEach((element, index) => element.classList.toggle("vui-face-shown", index === face));
    const image = this.faces[face]?.querySelector<HTMLElement>(".vui-tile-picture");
    if (image) {
      const zoom = 1 + (motion.pictureZoom - 1) * this.zoom.value;
      image.style.transform = zoom === 1 && this.driftX.value === 0 && this.driftY.value === 0 ? "" : `translate(${this.driftX.value}px, ${this.driftY.value}px) scale(${zoom})`;
    }
  };
}

/**
 * Where every tile is while `active` (or none) is emphasized: VUI's TileProjection, rule for rule, except that a
 * `centered` tile grows sideways from its center.
 */
function project(rest: Rect[], active: number, scale: number, gutter: number, centered: boolean): Rect[] {
  const current = rest.map((rect) => ({ ...rect }));
  if (active < 0 || scale <= 1) {
    return current;
  }

  const growth = scale - 1;
  const horizontalGrowth = rest[active].width * growth;
  const verticalGrowth = rest[active].height * growth;
  current[active] = {
    ...rest[active],
    x: centered ? rest[active].x - horizontalGrowth / 2 : rest[active].x,
    width: rest[active].width * scale,
    height: rest[active].height * scale
  };
  const reach = current.map((rect) => ({ ...rect }));
  const order = rest.map((_, index) => index).sort((first, second) => rest[first].y - rest[second].y || rest[first].x - rest[second].x);
  const movedRight = rest.map((_, index) => index === active);
  const movedDown = rest.map((_, index) => index === active);
  const right = (rect: Rect) => rect.x + rect.width;
  const bottom = (rect: Rect) => rect.y + rect.height;
  let changed = true;
  while (changed) {
    changed = false;
    for (const source of order) {
      for (const target of order) {
        if (source === target) {
          continue;
        }

        const sourceBounds = reach[source];
        const targetBounds = current[target];
        if (movedRight[source] && !movedRight[target]
          && right(rest[source]) <= rest[target].x
          && sourceBounds.y < bottom(targetBounds)
          && bottom(sourceBounds) > targetBounds.y
          && right(sourceBounds) > rest[target].x - gutter) {
          movedRight[target] = true;
          current[target] = { ...targetBounds, x: targetBounds.x + horizontalGrowth };
          reach[target] = current[target];
          changed = true;
        }

        if (movedDown[source] && !movedDown[target]
          && bottom(rest[source]) <= rest[target].y
          && sourceBounds.x < right(targetBounds)
          && right(sourceBounds) > targetBounds.x
          && bottom(sourceBounds) > rest[target].y - gutter) {
          movedDown[target] = true;
          current[target] = { ...targetBounds, y: targetBounds.y + verticalGrowth };
          reach[target] = current[target];
          changed = true;
        }
      }
    }
  }

  return current;
}

class Panel {
  private readonly tiles: TileMotion[];
  private pointerTile: TileMotion | null = null;
  private focusTile: TileMotion | null = null;
  private emphasized: TileMotion | null = null;
  private gutter = 0;
  private liveIndex = 0;
  private present = false;
  private staggered: number[] = [];
  private readonly headers: { element: HTMLElement; first: number; shown: Spring }[];

  constructor(private readonly wall: HTMLElement) {
    this.tiles = [...wall.querySelectorAll<HTMLElement>(".vui-tile")].map((element) => new TileMotion(element));
    this.headers = [...wall.querySelectorAll<HTMLElement>(".vui-group-header")].map((element) => {
      const first = this.tiles.findIndex((tile) => tile.element === element.parentElement?.querySelector(".vui-tile"));
      const shown: Spring = new Spring(0, presets.settle, 0.001, () => paint(() => (element.style.opacity = shown.value === 1 ? "" : String(shown.value))));
      element.style.opacity = "0";
      return { element, first: Math.max(first, 0), shown };
    });
    this.measure();
    for (const tile of this.tiles) {
      this.place(tile, tile.rest, true);
      tile.render();
      this.listen(tile);
    }

    // A wall on a page that is not shown waits, turned away, until its page arrives.
    this.wall.classList.add("vui-started");
    if (!wall.closest("[hidden]")) {
      this.arrive();
    }

    new ResizeObserver(() => {
      this.measure();
      this.follow(true);
    }).observe(wall);
    document.fonts?.ready.then(() => {
      this.measure();
      this.follow(true);
    });

    window.setInterval(this.flipNext, Number(wall.dataset.vuiLive) || 12000);
    for (const tile of this.tiles.filter((tile) => tile.rollInterval > 0)) {
      window.setInterval(() => {
        if (this.present && !document.hidden && tile !== this.held && tile.flip.target === 0) {
          tile.roll();
        }
      }, tile.rollInterval);
    }
  }

  private get held() {
    return this.pointerTile ?? this.focusTile;
  }

  /** The tiles' rest rectangles in the wall, from layout, which transforms do not change. */
  private measure() {
    for (const tile of this.tiles) {
      const { element } = tile;
      tile.rest = { x: element.offsetLeft, y: element.offsetTop, width: element.offsetWidth, height: element.offsetHeight };
    }

    const grid = this.wall.querySelector(".vui-group-tiles");
    this.gutter = grid ? parseFloat(getComputedStyle(grid).columnGap) || 0 : 0;
  }

  private place(tile: TileMotion, rect: Rect, jump: boolean) {
    const springs: [Spring, number][] = [[tile.x, rect.x], [tile.y, rect.y], [tile.width, rect.width], [tile.height, rect.height]];
    for (const [spring, value] of springs) {
      if (jump) {
        spring.jump(value);
      } else {
        spring.to(value);
      }
    }
  }

  /**
   * Each tile turns in (or back) from the side it is on, and a dived tile shrinks back, 40 ms after the one before
   * (less on a big wall); each group's title fades in with its first tile.
   */
  arrive() {
    this.present = true;
    const step = this.pace(motion.enterStagger);
    this.stagger(this.tiles.map((tile, index) => [index * step, () => {
      tile.away.to(0, presets.settle);
      tile.dive.to(0, presets.settle);
    }]));
    for (const header of this.headers) {
      window.setTimeout(() => header.shown.to(1, presets.settle), header.first * step);
    }
  }

  /**
   * Each tile turns away to the other side 25 ms after the one before (less on a big wall), while `opened` (the tile
   * that opened the next page, if any) dives toward the viewer; group titles fade. Resolves once everything has gone.
   */
  leave(opened: HTMLElement | null) {
    this.present = false;
    this.pointerTile = null;
    this.focusTile = null;
    this.follow();
    const step = this.pace(motion.exitStagger);
    this.stagger(this.tiles.map((tile, index) => [index * step, () => {
      if (tile.element === opened) {
        tile.dive.to(1, presets.exit);
      } else {
        tile.away.to(1, presets.exit);
      }
    }]));
    for (const header of this.headers) {
      header.shown.to(0, presets.exit);
    }

    // Arriving again before everything has gone ends the wait too; the caller then keeps the page.
    return new Promise<void>((resolve) => {
      const check = window.setInterval(() => {
        const gone = this.tiles.every((tile) => tile.away.resting && tile.dive.resting && (tile.away.target === 1 || tile.dive.target === 1));
        if (gone || this.present) {
          window.clearInterval(check);
          resolve();
        }
      }, 50);
    });
  }

  /** The time between two tiles' turns: `stagger`, shared out over a wall of more than `staggerSpan` tiles. */
  private pace(stagger: number) {
    return stagger * Math.min(1, motion.staggerSpan / this.tiles.length);
  }

  /** Runs each step after its delay, dropping the steps still waiting from the last stagger. */
  private stagger(steps: [number, () => void][]) {
    for (const timer of this.staggered) {
      window.clearTimeout(timer);
    }

    this.staggered = steps.map(([delay, step]) => window.setTimeout(step, delay));
  }

  private listen(tile: TileMotion) {
    const { element } = tile;
    element.addEventListener("pointerenter", () => {
      if (this.present) {
        this.pointerTile = tile;
        paint(this.follow);
      }
    });
    element.addEventListener("pointerleave", () => {
      if (this.pointerTile === tile) {
        this.pointerTile = null;
      }

      this.release(tile);
      paint(this.follow);
    });
    element.addEventListener("focusin", () => {
      if (this.present && element.matches(":focus-visible")) {
        this.focusTile = tile;
        paint(this.follow);
      }
    });
    element.addEventListener("focusout", () => {
      if (this.focusTile === tile) {
        this.focusTile = null;
      }

      this.release(tile);
      paint(this.follow);
    });
    if (!tile.interactive) {
      return;
    }

    element.addEventListener("pointerdown", (event) => {
      if (!this.present || event.button !== 0) {
        return;
      }

      const box = element.getBoundingClientRect();
      this.pressAt(tile, ((event.clientX - box.left) / box.width) * 2 - 1, ((event.clientY - box.top) / box.height) * 2 - 1);
    });
    element.addEventListener("pointerup", () => this.release(tile));
    element.addEventListener("pointercancel", () => this.release(tile));
    element.addEventListener("keydown", (event) => {
      if (!event.repeat && (event.key === "Enter" || event.key === " ")) {
        this.pressAt(tile, 0, 0);
      }
    });
    element.addEventListener("keyup", () => this.release(tile));
  }

  /** VUI's press: the tile presses in and leans away from the pressed point, given from −1 to 1 across it. */
  private pressAt(tile: TileMotion, x: number, y: number) {
    tile.press.to(1);
    tile.tiltY.to(x * motion.tiltDegrees);
    tile.tiltX.to(-y * motion.tiltDegrees);
  }

  private release(tile: TileMotion) {
    tile.press.to(0);
    tile.tiltX.to(0);
    tile.tiltY.to(0);
  }

  /** Points every tile at its place around the emphasized one and shows that tile behind the page. */
  private readonly follow = (jump = false) => {
    const emphasized = this.held;
    const index = emphasized ? this.tiles.indexOf(emphasized) : -1;
    if (emphasized && emphasized !== this.emphasized) {
      emphasized.direction = [Math.random() * 2 - 1, Math.random() * 2 - 1];
    }

    this.emphasized = emphasized;
    const projected = project(this.tiles.map((tile) => tile.rest), index, motion.emphasisScale, this.gutter, emphasized?.centered ?? false);
    this.tiles.forEach((tile, position) => {
      tile.element.style.zIndex = position === index ? "1" : "";
      tile.element.classList.toggle("vui-emphasized", position === index);
      this.place(tile, projected[position], jump === true);
      tile.hover.to(tile === this.pointerTile ? 1 : 0);
      // A picture covers its tile a little larger and drifts while emphasized, and settles back after.
      const overflow = (motion.pictureZoom - 1) / 2;
      if (tile === emphasized) {
        tile.zoom.to(1, presets.settle);
        tile.driftX.to(tile.direction[0] * overflow * tile.rest.width, presets.drift);
        tile.driftY.to(tile.direction[1] * overflow * tile.rest.height, presets.drift);
      } else {
        tile.zoom.to(0, presets.settle);
        tile.driftX.to(0, presets.settle);
        tile.driftY.to(0, presets.settle);
      }
    });
    pageBackdrop().show(emphasized?.wash ?? null, emphasized?.picture ?? null);
  };

  /** Turns a flipped tile back, or else flips the next live tile, so only one tile shows its back at a time. */
  private readonly flipNext = () => {
    if (!this.present || document.hidden) {
      return;
    }

    // A tile under the pointer or the keyboard focus is not turned, so its picture and backdrop are left alone.
    const held = this.held;
    const live = this.tiles.filter((tile) => tile.live && tile !== held);
    const flipped = live.find((tile) => tile.flip.target === 180);
    if (flipped) {
      flipped.flip.to(0);
      return;
    }

    if (live.length > 0) {
      this.liveIndex = (this.liveIndex + 1) % live.length;
      live[this.liveIndex].flip.to(180);
    }
  };
}

const panels = new WeakMap<HTMLElement, Panel>();

/** Starts the tile wall `wall`. */
export function startPanel(wall: HTMLElement) {
  panels.set(wall, new Panel(wall));
}

/** The running panel of the tile wall `wall`, if it has started. */
export function wallPanel(wall: HTMLElement) {
  return panels.get(wall);
}
