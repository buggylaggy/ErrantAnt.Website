# VUI.Web

The VTile (Metro) language of [VUI.Avalonia](https://github.com/jusvail/VUI.Avalonia) for Astro sites: a translucent top
bar, groups of tiles that enter in a stagger and press in like the apps' tiles, and the start page's graph-paper grid
that makes one random move, turn and zoom when the page opens. A site brings its own colors through the `--vui-*`
tokens; the package holds only what every site shares.

The package is the npm package `vui-web`, shipped as Astro source with `astro` 7 as a peer dependency. It is private
and never published to a registry: a site pins a packed version in its own repository.

## Components

```astro
---
import "vui-web/vui.css";
import GridBackdrop from "vui-web/GridBackdrop.astro";
import TopBar from "vui-web/TopBar.astro";
import TileGroup from "vui-web/TileGroup.astro";
import Tile from "vui-web/Tile.astro";
---
<GridBackdrop />
<TopBar>
  <h1 class="vui-bar-brand" slot="brand">Name</h1>
  <a href="#first">First</a>
</TopBar>
<main class="vui-groups">
  <TileGroup title="First" id="first">
    <Tile cols={4} rows={2} color="#3e4a5c" label="Label" title="Title" caption="Caption" />
    <Tile cols={2} rows={2} color="var(--vui-accent)" title="Press me" button />
  </TileGroup>
</main>
```

- `GridBackdrop`: the fixed graph paper behind the page (a canvas), drawn in `--vui-grid-ink` at `--vui-grid-opacity`.
- `TopBar`: a sticky bar of `--vui-chrome` that blurs what scrolls under it. The `brand` slot takes the brand element
  (class `vui-bar-brand` gives it the pivot type); the default slot takes section links.
- `TileGroup`: a titled group four cells wide; groups go in a `.vui-groups` container, side by side, wrapping.
- `Tile`: `cols` and `rows` (1–4 cells), `color`, optional `label` (top), `title` and `caption` (bottom) and a default
  slot for drawn content. `href` makes the tile a link and `button` a button; those show their edge on hover and press
  in toward the pointer. Other attributes go to the tile element.

## Tokens

Set on `:root` by the site after importing `vui.css`:

- Scheme: `--vui-canvas`, `--vui-chrome`, `--vui-ink`, `--vui-muted`, `--vui-accent`, `--vui-on-tile`,
  `--vui-tile-color` (the default tile color), `--vui-tile-edge`, `--vui-tile-opacity`, `--vui-bar-opacity`,
  `--vui-grid-ink`, `--vui-grid-opacity`, `--vui-font`.
- Geometry: `--vui-cell` sets the tile cell; `--vui-u` (one VUI pixel at the apps' 960 by 600 base scale, `cell / 53`)
  scales every other size. Below 560 px one group fills the width.

## Using it in a site

Pack a version and copy the tarball into the site's `packages/` folder:

```sh
npm run pack
cp artifacts/vui-web-0.1.0.tgz ../ErrantAnt.Website/packages/
```

The site depends on that exact file, so its GitHub Pages build needs nothing outside its own repository:

```json
"dependencies": {
  "vui-web": "file:packages/vui-web-0.1.0.tgz"
}
```

A change to the package is a new version in `package.json`, packed and pinned by each site that takes it; a version a
site already uses is never overwritten.
